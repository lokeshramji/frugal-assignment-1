from dataclasses import dataclass

@dataclass
class CircuitBreaker:
    max_attempts: int = 3
    attempts: int = 0
    def allow(self) -> bool:
        if self.attempts >= self.max_attempts:
            return False
        self.attempts += 1
        return True
    def reset(self):
        self.attempts = 0
