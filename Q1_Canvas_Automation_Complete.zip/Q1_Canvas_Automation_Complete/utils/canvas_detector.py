from playwright.sync_api import Page

DETECTOR_JS = r'''({selector, rgb, tolerance, timeoutMs}) => {
  const canvas = document.querySelector(selector);
  if (!canvas) throw new Error('Canvas not found: ' + selector);
  const ctx = canvas.getContext('2d', {willReadFrequently:true});
  const started = performance.now();
  const matches = (r,g,b) => Math.abs(r-rgb[0]) <= tolerance && Math.abs(g-rgb[1]) <= tolerance && Math.abs(b-rgb[2]) <= tolerance;
  return new Promise((resolve,reject) => {
    function frame() {
      const image = ctx.getImageData(0,0,canvas.width,canvas.height);
      for (let y=0; y<canvas.height; y+=2) {
        for (let x=0; x<canvas.width; x+=2) {
          const i=(y*canvas.width+x)*4;
          if (matches(image.data[i], image.data[i+1], image.data[i+2])) {
            resolve({x,y,detectedAt:performance.now()}); return;
          }
        }
      }
      if (performance.now()-started >= timeoutMs) { reject(new Error('Active Canvas color not detected before timeout')); return; }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  });
}'''

def detect_active_target(page: Page, timeout_ms: int = 6000):
    return page.evaluate(DETECTOR_JS, {
        'selector':'#board', 'rgb':[34,197,94], 'tolerance':18, 'timeoutMs':timeout_ms
    })
