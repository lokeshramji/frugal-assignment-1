from dataclasses import dataclass
import time


def fibonacci(n: int) -> int:
    if n <= 0:
        return 0
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a

@dataclass
class JitterEvent:
    step: int
    delay_ms: int
    timestamp: float
    direction: str

class FibonacciJitter:
    CAP_MS = 8000
    def __init__(self):
        self.step = 1
        self.events: list[JitterEvent] = []
    def delay_for_step(self, step: int) -> int:
        return min(fibonacci(step) * 1000, self.CAP_MS)
    def record(self, direction: str = 'server->browser') -> int:
        delay = self.delay_for_step(self.step)
        self.events.append(JitterEvent(self.step, delay, time.time(), direction))
        self.step += 1
        return delay
